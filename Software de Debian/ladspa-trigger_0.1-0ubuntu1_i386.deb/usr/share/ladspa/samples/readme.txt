These samples are licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 2.0 license.

http://creativecommons.org/licenses/by-nc-sa/2.0/

Recording details:
Tama Swingstar drums

Nady drum mics on toms
AKG overheads
Shure SM57 on snare

Recorded using Logic Audio 6.3.1 on a Power Mac G4 400.

Samples are converted from 16 bit AIFF to 16 bit WAVE files, sampled at 44.1 kHz

2004 Curvedspace Productions.  Some rights reserved.

http://curvedspace.org
