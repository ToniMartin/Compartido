# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/error_message.ui'
#
# Created: Thu May 10 17:39:12 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_ErrorPage(object):
    def setupUi(self, ErrorPage):
        ErrorPage.setObjectName(_fromUtf8("ErrorPage"))
        ErrorPage.resize(400, 300)
        self.verticalLayout = QtGui.QVBoxLayout(ErrorPage)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.error_message_label = QtGui.QLabel(ErrorPage)
        self.error_message_label.setText(_fromUtf8("TextLabel"))
        self.error_message_label.setAlignment(QtCore.Qt.AlignCenter)
        self.error_message_label.setObjectName(_fromUtf8("error_message_label"))
        self.verticalLayout.addWidget(self.error_message_label)

        self.retranslateUi(ErrorPage)
        QtCore.QMetaObject.connectSlotsByName(ErrorPage)

    def retranslateUi(self, ErrorPage):
        pass

