# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/filesyncstatus.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(94, 52)
        Form.setWindowTitle(_fromUtf8("Form"))
        self.verticalLayout = QtGui.QVBoxLayout(Form)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.sync_status_icon = QtGui.QLabel(Form)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.sync_status_icon.sizePolicy().hasHeightForWidth())
        self.sync_status_icon.setSizePolicy(sizePolicy)
        self.sync_status_icon.setObjectName(_fromUtf8("sync_status_icon"))
        self.horizontalLayout.addWidget(self.sync_status_icon)
        self.sync_status_label = QtGui.QLabel(Form)
        self.sync_status_label.setText(_fromUtf8(""))
        self.sync_status_label.setWordWrap(True)
        self.sync_status_label.setObjectName(_fromUtf8("sync_status_label"))
        self.horizontalLayout.addWidget(self.sync_status_label)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.sync_status_button = QtGui.QPushButton(Form)
        self.sync_status_button.setProperty("secondary", True)
        self.sync_status_button.setObjectName(_fromUtf8("sync_status_button"))
        self.verticalLayout.addWidget(self.sync_status_button)
        self.sync_status_label.setBuddy(self.sync_status_button)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

