# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/local_folders.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(274, 312)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Form)
        self.verticalLayout_2.setContentsMargins(-1, 0, -1, -1)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.folders = QtGui.QTreeWidget(Form)
        self.folders.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
        self.folders.setAlternatingRowColors(True)
        self.folders.setIndentation(0)
        self.folders.setRootIsDecorated(False)
        self.folders.setUniformRowHeights(True)
        self.folders.setAllColumnsShowFocus(True)
        self.folders.setObjectName(_fromUtf8("folders"))
        self.folders.headerItem().setText(0, _fromUtf8("Sync these folders on my computer"))
        self.folders.headerItem().setText(1, _fromUtf8("Space (Total)"))
        self.folders.header().setStretchLastSection(False)
        self.verticalLayout_2.addWidget(self.folders)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem)
        self.add_folder_button = AddFolderButton(Form)
        self.add_folder_button.setText(_fromUtf8("Add a folder"))
        self.add_folder_button.setDefault(True)
        self.add_folder_button.setProperty("DisabledState", False)
        self.add_folder_button.setObjectName(_fromUtf8("add_folder_button"))
        self.horizontalLayout_3.addWidget(self.add_folder_button)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem1)
        self.verticalLayout_2.addLayout(self.horizontalLayout_3)
        self.offer_frame = QtGui.QFrame(Form)
        self.offer_frame.setObjectName(_fromUtf8("offer_frame"))
        self.verticalLayout = QtGui.QVBoxLayout(self.offer_frame)
        self.verticalLayout.setContentsMargins(0, -1, 0, -1)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.offer_label = QtGui.QLabel(self.offer_frame)
        self.offer_label.setText(_fromUtf8("overflow message"))
        self.offer_label.setWordWrap(True)
        self.offer_label.setObjectName(_fromUtf8("offer_label"))
        self.verticalLayout.addWidget(self.offer_label)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.add_storage_button = GetStorageButton(self.offer_frame)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.add_storage_button.sizePolicy().hasHeightForWidth())
        self.add_storage_button.setSizePolicy(sizePolicy)
        self.add_storage_button.setText(_fromUtf8("add storage"))
        self.add_storage_button.setDefault(True)
        self.add_storage_button.setObjectName(_fromUtf8("add_storage_button"))
        self.horizontalLayout.addWidget(self.add_storage_button)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem3)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.verticalLayout_2.addWidget(self.offer_frame)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

from ubuntuone.controlpanel.gui.qt.gotoweb import GetStorageButton
from ubuntuone.controlpanel.gui.qt.addfolder import AddFolderButton
