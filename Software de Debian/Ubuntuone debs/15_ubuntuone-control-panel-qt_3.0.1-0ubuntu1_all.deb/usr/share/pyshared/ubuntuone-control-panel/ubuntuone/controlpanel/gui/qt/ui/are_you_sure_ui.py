# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/are_you_sure.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(409, 196)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.title_label = QtGui.QLabel(Dialog)
        self.title_label.setText(_fromUtf8("Are you sure?"))
        self.title_label.setTextFormat(QtCore.Qt.PlainText)
        self.title_label.setObjectName(_fromUtf8("title_label"))
        self.verticalLayout.addWidget(self.title_label)
        self.message_label = QtGui.QLabel(Dialog)
        self.message_label.setText(_fromUtf8("more explanation"))
        self.message_label.setTextFormat(QtCore.Qt.AutoText)
        self.message_label.setWordWrap(True)
        self.message_label.setOpenExternalLinks(True)
        self.message_label.setObjectName(_fromUtf8("message_label"))
        self.verticalLayout.addWidget(self.message_label)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.yes_button = QtGui.QPushButton(Dialog)
        self.yes_button.setText(_fromUtf8("Yeah"))
        self.yes_button.setAutoDefault(False)
        self.yes_button.setObjectName(_fromUtf8("yes_button"))
        self.horizontalLayout.addWidget(self.yes_button)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.no_button = QtGui.QPushButton(Dialog)
        self.no_button.setText(_fromUtf8("Nopes"))
        self.no_button.setDefault(True)
        self.no_button.setObjectName(_fromUtf8("no_button"))
        self.horizontalLayout.addWidget(self.no_button)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem3)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.no_button, QtCore.SIGNAL(_fromUtf8("clicked()")), Dialog.reject)
        QtCore.QObject.connect(self.yes_button, QtCore.SIGNAL(_fromUtf8("clicked()")), Dialog.accept)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        pass

