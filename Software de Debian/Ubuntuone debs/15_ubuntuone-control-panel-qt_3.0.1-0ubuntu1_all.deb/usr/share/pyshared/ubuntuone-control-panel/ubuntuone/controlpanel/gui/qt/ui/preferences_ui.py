# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/preferences.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(520, 311)
        Form.setWindowTitle(_fromUtf8("Form"))
        Form.setStyleSheet(_fromUtf8(""))
        self.verticalLayout = QtGui.QVBoxLayout(Form)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.bandwidth_settings = QtGui.QGroupBox(Form)
        self.bandwidth_settings.setTitle(_fromUtf8("Bandwidth Settings"))
        self.bandwidth_settings.setObjectName(_fromUtf8("bandwidth_settings"))
        self.gridLayout = QtGui.QGridLayout(self.bandwidth_settings)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.limit_uploads_checkbox = QtGui.QCheckBox(self.bandwidth_settings)
        self.limit_uploads_checkbox.setText(_fromUtf8("Limit upload speed to"))
        self.limit_uploads_checkbox.setObjectName(_fromUtf8("limit_uploads_checkbox"))
        self.gridLayout.addWidget(self.limit_uploads_checkbox, 0, 0, 1, 1)
        self.upload_speed_spinbox = QtGui.QSpinBox(self.bandwidth_settings)
        self.upload_speed_spinbox.setMinimum(-1)
        self.upload_speed_spinbox.setMaximum(999999999)
        self.upload_speed_spinbox.setObjectName(_fromUtf8("upload_speed_spinbox"))
        self.gridLayout.addWidget(self.upload_speed_spinbox, 0, 1, 1, 1)
        self.kbps_label_1 = QtGui.QLabel(self.bandwidth_settings)
        self.kbps_label_1.setText(_fromUtf8("Kilobits per second"))
        self.kbps_label_1.setObjectName(_fromUtf8("kbps_label_1"))
        self.gridLayout.addWidget(self.kbps_label_1, 0, 2, 1, 1)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 3, 1, 1)
        self.limit_downloads_checkbox = QtGui.QCheckBox(self.bandwidth_settings)
        self.limit_downloads_checkbox.setText(_fromUtf8("Limit download speed to"))
        self.limit_downloads_checkbox.setObjectName(_fromUtf8("limit_downloads_checkbox"))
        self.gridLayout.addWidget(self.limit_downloads_checkbox, 1, 0, 1, 1)
        self.download_speed_spinbox = QtGui.QSpinBox(self.bandwidth_settings)
        self.download_speed_spinbox.setMinimum(-1)
        self.download_speed_spinbox.setMaximum(999999999)
        self.download_speed_spinbox.setObjectName(_fromUtf8("download_speed_spinbox"))
        self.gridLayout.addWidget(self.download_speed_spinbox, 1, 1, 1, 1)
        self.kbps_label_2 = QtGui.QLabel(self.bandwidth_settings)
        self.kbps_label_2.setText(_fromUtf8("Kilobits per second"))
        self.kbps_label_2.setObjectName(_fromUtf8("kbps_label_2"))
        self.gridLayout.addWidget(self.kbps_label_2, 1, 2, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(40, 10, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem1, 2, 0, 1, 1)
        self.label_2 = QtGui.QLabel(self.bandwidth_settings)
        self.label_2.setText(_fromUtf8("Please note that your files will not sync if you set bandwidth to 0"))
        self.label_2.setScaledContents(False)
        self.label_2.setWordWrap(False)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 3, 0, 1, 3)
        self.verticalLayout.addWidget(self.bandwidth_settings)
        self.file_sync_settings = QtGui.QGroupBox(Form)
        self.file_sync_settings.setTitle(_fromUtf8("File Sync Settings"))
        self.file_sync_settings.setObjectName(_fromUtf8("file_sync_settings"))
        self.gridLayout_2 = QtGui.QGridLayout(self.file_sync_settings)
        self.gridLayout_2.setMargin(0)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.autoconnect_checkbox = QtGui.QCheckBox(self.file_sync_settings)
        self.autoconnect_checkbox.setText(_fromUtf8("Connect automatically when computer starts"))
        self.autoconnect_checkbox.setObjectName(_fromUtf8("autoconnect_checkbox"))
        self.gridLayout_2.addWidget(self.autoconnect_checkbox, 0, 0, 1, 1)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem2, 0, 1, 1, 1)
        self.udf_autosubscribe_checkbox = QtGui.QCheckBox(self.file_sync_settings)
        self.udf_autosubscribe_checkbox.setText(_fromUtf8("Automatically sync all new cloud folders to this computer"))
        self.udf_autosubscribe_checkbox.setObjectName(_fromUtf8("udf_autosubscribe_checkbox"))
        self.gridLayout_2.addWidget(self.udf_autosubscribe_checkbox, 1, 0, 1, 1)
        self.share_autosubscribe_checkbox = QtGui.QCheckBox(self.file_sync_settings)
        self.share_autosubscribe_checkbox.setText(_fromUtf8("Automatically sync all folders shared with me to this computer"))
        self.share_autosubscribe_checkbox.setObjectName(_fromUtf8("share_autosubscribe_checkbox"))
        self.gridLayout_2.addWidget(self.share_autosubscribe_checkbox, 2, 0, 1, 1)
        self.show_all_notifications_checkbox = QtGui.QCheckBox(self.file_sync_settings)
        self.show_all_notifications_checkbox.setText(_fromUtf8("Allow all notifications to this device"))
        self.show_all_notifications_checkbox.setObjectName(_fromUtf8("show_all_notifications_checkbox"))
        self.gridLayout_2.addWidget(self.show_all_notifications_checkbox, 3, 0, 1, 1)
        self.verticalLayout.addWidget(self.file_sync_settings)
        spacerItem3 = QtGui.QSpacerItem(20, 10, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setMargin(3)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem4)
        self.restore_defaults_button = QtGui.QPushButton(Form)
        self.restore_defaults_button.setText(_fromUtf8("Default settings"))
        self.restore_defaults_button.setProperty("secondary", True)
        self.restore_defaults_button.setObjectName(_fromUtf8("restore_defaults_button"))
        self.horizontalLayout.addWidget(self.restore_defaults_button)
        self.apply_changes_button = QtGui.QPushButton(Form)
        self.apply_changes_button.setText(_fromUtf8("Apply these settings"))
        self.apply_changes_button.setDefault(True)
        self.apply_changes_button.setObjectName(_fromUtf8("apply_changes_button"))
        self.horizontalLayout.addWidget(self.apply_changes_button)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

