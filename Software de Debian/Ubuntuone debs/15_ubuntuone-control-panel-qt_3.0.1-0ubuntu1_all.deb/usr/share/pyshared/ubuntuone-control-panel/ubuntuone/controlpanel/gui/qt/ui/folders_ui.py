# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/folders.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(393, 279)
        Form.setWindowTitle(_fromUtf8("Form"))
        self.verticalLayout = QtGui.QVBoxLayout(Form)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.frame_top = QtGui.QFrame(Form)
        self.frame_top.setMinimumSize(QtCore.QSize(0, 35))
        self.frame_top.setObjectName(_fromUtf8("frame_top"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.frame_top)
        self.horizontalLayout_2.setMargin(3)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.share_publish_button = GoToWebButton(self.frame_top)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.share_publish_button.sizePolicy().hasHeightForWidth())
        self.share_publish_button.setSizePolicy(sizePolicy)
        self.share_publish_button.setText(_fromUtf8("Go to the web for public and private sharing options"))
        self.share_publish_button.setFlat(True)
        self.share_publish_button.setObjectName(_fromUtf8("share_publish_button"))
        self.horizontalLayout_2.addWidget(self.share_publish_button)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.verticalLayout.addWidget(self.frame_top)
        self.folders = QtGui.QTreeWidget(Form)
        self.folders.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
        self.folders.setAlternatingRowColors(True)
        self.folders.setIndentation(15)
        self.folders.setRootIsDecorated(False)
        self.folders.setItemsExpandable(True)
        self.folders.setHeaderHidden(True)
        self.folders.setObjectName(_fromUtf8("folders"))
        self.folders.headerItem().setText(0, _fromUtf8("Name"))
        self.folders.headerItem().setText(1, _fromUtf8("Sync Locally?"))
        self.folders.headerItem().setText(2, _fromUtf8("Explore"))
        self.folders.header().setVisible(False)
        self.folders.header().setCascadingSectionResizes(False)
        self.folders.header().setDefaultSectionSize(300)
        self.folders.header().setHighlightSections(False)
        self.folders.header().setSortIndicatorShown(False)
        self.folders.header().setStretchLastSection(False)
        self.verticalLayout.addWidget(self.folders)
        self.frame_bottom = QtGui.QFrame(Form)
        self.frame_bottom.setMinimumSize(QtCore.QSize(0, 40))
        self.frame_bottom.setObjectName(_fromUtf8("frame_bottom"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.frame_bottom)
        self.horizontalLayout.setMargin(3)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem1 = QtGui.QSpacerItem(53, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.add_folder_button = AddFolderButton(self.frame_bottom)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.add_folder_button.sizePolicy().hasHeightForWidth())
        self.add_folder_button.setSizePolicy(sizePolicy)
        self.add_folder_button.setText(_fromUtf8("Add a folder"))
        self.add_folder_button.setDefault(True)
        self.add_folder_button.setObjectName(_fromUtf8("add_folder_button"))
        self.horizontalLayout.addWidget(self.add_folder_button)
        self.check_settings_button = QtGui.QPushButton(self.frame_bottom)
        self.check_settings_button.setText(_fromUtf8("Check settings"))
        self.check_settings_button.setObjectName(_fromUtf8("check_settings_button"))
        self.horizontalLayout.addWidget(self.check_settings_button)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.verticalLayout.addWidget(self.frame_bottom)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

from ubuntuone.controlpanel.gui.qt.gotoweb import GoToWebButton
from ubuntuone.controlpanel.gui.qt.addfolder import AddFolderButton
