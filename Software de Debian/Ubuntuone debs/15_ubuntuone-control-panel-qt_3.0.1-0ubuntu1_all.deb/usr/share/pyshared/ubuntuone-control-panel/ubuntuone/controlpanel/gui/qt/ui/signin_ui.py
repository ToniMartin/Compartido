# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/signin.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(370, 447)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Form)
        self.verticalLayout_2.setMargin(0)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.signin = QtGui.QFrame(Form)
        self.signin.setObjectName(_fromUtf8("signin"))
        self.sign_in = QtGui.QVBoxLayout(self.signin)
        self.sign_in.setMargin(0)
        self.sign_in.setObjectName(_fromUtf8("sign_in"))
        self.frame = QtGui.QFrame(self.signin)
        self.frame.setObjectName(_fromUtf8("frame"))
        self.horizontalLayout_3 = QtGui.QHBoxLayout(self.frame)
        self.horizontalLayout_3.setContentsMargins(0, 22, 0, 0)
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.banner = QtGui.QLabel(self.frame)
        self.banner.setText(_fromUtf8(""))
        self.banner.setTextFormat(QtCore.Qt.PlainText)
        self.banner.setPixmap(QtGui.QPixmap(_fromUtf8(":/banner.png")))
        self.banner.setAlignment(QtCore.Qt.AlignCenter)
        self.banner.setWordWrap(True)
        self.banner.setObjectName(_fromUtf8("banner"))
        self.horizontalLayout_3.addWidget(self.banner)
        self.sign_in.addWidget(self.frame)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.sign_in.addItem(spacerItem)
        self.welcome_label = QtGui.QLabel(self.signin)
        self.welcome_label.setText(_fromUtf8("Welcome to Ubuntu One"))
        self.welcome_label.setAlignment(QtCore.Qt.AlignCenter|QtCore.Qt.AlignHCenter|QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.welcome_label.setObjectName(_fromUtf8("welcome_label"))
        self.sign_in.addWidget(self.welcome_label)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.sign_in.addItem(spacerItem1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.login_button = QtGui.QPushButton(self.signin)
        self.login_button.setText(_fromUtf8("Existing account"))
        self.login_button.setDefault(True)
        self.login_button.setObjectName(_fromUtf8("login_button"))
        self.verticalLayout.addWidget(self.login_button)
        self.register_button = QtGui.QPushButton(self.signin)
        self.register_button.setText(_fromUtf8("Setup new account"))
        self.register_button.setObjectName(_fromUtf8("register_button"))
        self.verticalLayout.addWidget(self.register_button)
        self.horizontalLayout.addLayout(self.verticalLayout)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem3)
        self.sign_in.addLayout(self.horizontalLayout)
        self.verticalLayout_2.addWidget(self.signin)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

import images_rc
