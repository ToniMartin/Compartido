# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/devices.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(393, 281)
        Form.setWindowTitle(_fromUtf8("Form"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(Form)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setMargin(0)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.local_device_box = QtGui.QGroupBox(Form)
        self.local_device_box.setTitle(_fromUtf8("This device"))
        self.local_device_box.setObjectName(_fromUtf8("local_device_box"))
        self.local_device_layout = QtGui.QVBoxLayout(self.local_device_box)
        self.local_device_layout.setMargin(0)
        self.local_device_layout.setObjectName(_fromUtf8("local_device_layout"))
        self.local_device = DeviceWidget(self.local_device_box)
        self.local_device.setObjectName(_fromUtf8("local_device"))
        self.local_device_layout.addWidget(self.local_device)
        self.verticalLayout_3.addWidget(self.local_device_box)
        self.other_devices = QtGui.QGroupBox(Form)
        self.other_devices.setTitle(_fromUtf8("Other devices"))
        self.other_devices.setObjectName(_fromUtf8("other_devices"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.other_devices)
        self.verticalLayout_2.setMargin(0)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.list_devices = QtGui.QListWidget(self.other_devices)
        self.list_devices.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
        self.list_devices.setAlternatingRowColors(True)
        self.list_devices.setIconSize(QtCore.QSize(32, 32))
        self.list_devices.setSpacing(0)
        self.list_devices.setSelectionRectVisible(False)
        self.list_devices.setObjectName(_fromUtf8("list_devices"))
        self.verticalLayout_2.addWidget(self.list_devices)
        self.verticalLayout_3.addWidget(self.other_devices)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setMargin(3)
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem)
        self.manage_devices_button = GoToWebButton(Form)
        self.manage_devices_button.setText(_fromUtf8("Go to the web page to manage your other devices"))
        self.manage_devices_button.setDefault(True)
        self.manage_devices_button.setObjectName(_fromUtf8("manage_devices_button"))
        self.horizontalLayout_3.addWidget(self.manage_devices_button)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem1)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

from ubuntuone.controlpanel.gui.qt.device import DeviceWidget
from ubuntuone.controlpanel.gui.qt.gotoweb import GoToWebButton
import images_rc
