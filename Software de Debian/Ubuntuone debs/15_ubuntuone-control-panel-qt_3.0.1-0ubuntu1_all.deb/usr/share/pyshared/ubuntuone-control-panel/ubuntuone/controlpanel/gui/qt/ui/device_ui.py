# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/device.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(430, 27)
        Form.setWindowTitle(_fromUtf8("Form"))
        self.horizontalLayout = QtGui.QHBoxLayout(Form)
        self.horizontalLayout.setMargin(0)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.device_icon_label = QtGui.QLabel(Form)
        self.device_icon_label.setPixmap(QtGui.QPixmap(_fromUtf8(":/computer.png")))
        self.device_icon_label.setObjectName(_fromUtf8("device_icon_label"))
        self.horizontalLayout.addWidget(self.device_icon_label)
        self.device_name_label = QtGui.QLabel(Form)
        self.device_name_label.setText(_fromUtf8("Local device"))
        self.device_name_label.setObjectName(_fromUtf8("device_name_label"))
        self.horizontalLayout.addWidget(self.device_name_label)
        spacerItem = QtGui.QSpacerItem(217, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.remove_device_button = QtGui.QPushButton(Form)
        self.remove_device_button.setText(_fromUtf8("Remove"))
        self.remove_device_button.setProperty("secondary", True)
        self.remove_device_button.setObjectName(_fromUtf8("remove_device_button"))
        self.horizontalLayout.addWidget(self.remove_device_button)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

import images_rc
