# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/qt/account.ui'
#
# Created: Tue Jun  5 16:44:28 2012
#      by: PyQt4 UI code generator 4.9.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(381, 167)
        Form.setWindowTitle(_fromUtf8("Form"))
        self.verticalLayout = QtGui.QVBoxLayout(Form)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setVerticalSpacing(30)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.edit_profile_button = GoToWebButton(Form)
        self.edit_profile_button.setText(_fromUtf8("Edit personal details online"))
        self.edit_profile_button.setDefault(True)
        self.edit_profile_button.setObjectName(_fromUtf8("edit_profile_button"))
        self.gridLayout_2.addWidget(self.edit_profile_button, 0, 2, 1, 1)
        self.services = QtGui.QGroupBox(Form)
        self.services.setTitle(_fromUtf8("Your services"))
        self.services.setObjectName(_fromUtf8("services"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.services)
        self.verticalLayout_3.setContentsMargins(10, 0, 0, 0)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.services_description_label = QtGui.QLabel(self.services)
        self.services_description_label.setText(_fromUtf8(""))
        self.services_description_label.setObjectName(_fromUtf8("services_description_label"))
        self.verticalLayout_3.addWidget(self.services_description_label)
        self.gridLayout_2.addWidget(self.services, 2, 0, 1, 1)
        self.account_separator = QtGui.QFrame(Form)
        self.account_separator.setFrameShape(QtGui.QFrame.HLine)
        self.account_separator.setFrameShadow(QtGui.QFrame.Sunken)
        self.account_separator.setObjectName(_fromUtf8("account_separator"))
        self.gridLayout_2.addWidget(self.account_separator, 1, 0, 1, 4)
        self.profile_info = QtGui.QGroupBox(Form)
        self.profile_info.setTitle(_fromUtf8("Personal details"))
        self.profile_info.setObjectName(_fromUtf8("profile_info"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.profile_info)
        self.verticalLayout_4.setContentsMargins(10, 0, 0, 0)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setContentsMargins(6, -1, -1, -1)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.name_label = QtGui.QLabel(self.profile_info)
        self.name_label.setText(_fromUtf8(""))
        self.name_label.setObjectName(_fromUtf8("name_label"))
        self.verticalLayout_2.addWidget(self.name_label)
        self.email_label = QtGui.QLabel(self.profile_info)
        self.email_label.setText(_fromUtf8(""))
        self.email_label.setObjectName(_fromUtf8("email_label"))
        self.verticalLayout_2.addWidget(self.email_label)
        self.verticalLayout_4.addLayout(self.verticalLayout_2)
        self.gridLayout_2.addWidget(self.profile_info, 0, 0, 1, 1)
        self.edit_services_button = GoToWebButton(Form)
        self.edit_services_button.setText(_fromUtf8("Edit your services online"))
        self.edit_services_button.setDefault(True)
        self.edit_services_button.setObjectName(_fromUtf8("edit_services_button"))
        self.gridLayout_2.addWidget(self.edit_services_button, 2, 2, 1, 1)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem, 0, 3, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem1, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_2)
        spacerItem2 = QtGui.QSpacerItem(20, 10, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem2)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        pass

from ubuntuone.controlpanel.gui.qt.gotoweb import GoToWebButton
